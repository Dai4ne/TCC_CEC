# TCC_CEC
TCC 2025 - Controle de Equipamentos do Candelária
